# Dungeon Game 4

This is a simple game where you walk blindly in the dungeon,
collecting treasures, avoiding traps and enemies. 

## Usage

Run main with python