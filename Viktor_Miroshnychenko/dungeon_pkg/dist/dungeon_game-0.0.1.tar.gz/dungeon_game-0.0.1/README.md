Package with dungeon game.
This is a package was created to understand a process of package creating. 