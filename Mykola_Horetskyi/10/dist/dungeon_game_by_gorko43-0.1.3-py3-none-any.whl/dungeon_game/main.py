from game import DungeonGame

current_game = DungeonGame()
current_game.game_loop()
