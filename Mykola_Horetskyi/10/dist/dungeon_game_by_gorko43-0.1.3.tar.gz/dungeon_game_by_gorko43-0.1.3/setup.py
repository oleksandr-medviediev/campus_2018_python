import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="dungeon_game_by_gorko43",
    version="0.1.3",
    author="Mykola Horetskyi",
    packages=setuptools.find_packages()
)
