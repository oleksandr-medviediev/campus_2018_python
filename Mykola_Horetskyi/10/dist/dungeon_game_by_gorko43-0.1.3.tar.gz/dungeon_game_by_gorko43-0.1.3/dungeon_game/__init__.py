"""
pip install -i https://test.pypi.org/simple/ dungeon-game-by-gorko43
"""

name = "dungeon_game"

from . import *



