#outputs debug in stream in addition to log file
debug_mode = False

#adds to debug information about called functions, their arguments and returns
function_debug = False
