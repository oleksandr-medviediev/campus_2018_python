This is README file for DungeonGameLily package, made by Lily Panchenko.

DungeonGameLily is a simple, but important project, it passed with us the whole way of learning base Python concepts and
 now it's time to learn how to create our own packages. And so, DungeonGameLily was uploaded to test.pypi

As for now DungeonGame is a simple game. It has one player and one enemy in game. The aim is to collect three treasures 
and don't die before it. Enemy moves every 3 seconds and if it meets player - it attacks player, so player lose 1 health
 point. 
