#https://test.pypi.org/project/dungeon-game-package-ydzhuryn/

from .main import run
