from . import *

name = "dungeon_game_mykhailovskyi"
