from setuptools import setup

setup(name='dungeon_game_mykhailovskyi',
      version='0.1.6',
      description='Console game made during Python learning.',
      url='https://github.com/vonKleve/campus_2018_python',
      author='Mykhailovskyi Oleksandr',
      license='MIT',
      packages=['dungeon_game_mykhailovskyi'],
      zip_safe=False)
