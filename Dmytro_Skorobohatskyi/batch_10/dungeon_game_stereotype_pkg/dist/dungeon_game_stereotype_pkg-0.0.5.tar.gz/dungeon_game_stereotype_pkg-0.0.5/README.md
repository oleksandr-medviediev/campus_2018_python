# Dungeon Game Package

This is a simple dungeon game package.
You need find the treasure, do not get trapped and run away from enemy.
You can see it on https://github.com/Stereotype97/campus_2018_python/tree/Dmytro_Skorobohatskyi