from .game import Game

def run_game():
    game_session = Game()
    game_session.run()

if __name__ == '__main__':
    run_game()
