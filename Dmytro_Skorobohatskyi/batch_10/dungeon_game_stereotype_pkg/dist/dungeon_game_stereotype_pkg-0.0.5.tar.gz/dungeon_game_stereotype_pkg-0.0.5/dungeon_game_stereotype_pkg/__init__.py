name = 'dungeon_game_stereotype_pkg'

from .game_starter import run_game

