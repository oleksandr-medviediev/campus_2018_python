#Python_project_packaging
This is a simple example package. You can use
https://github.com/Serhiyko/Python_project_packaging
to write your content.